﻿using UnityEngine;
using System.Collections;

public class ItemInfo : MonoBehaviour
{
    public string Item_Name;
	// Use this for initialization
	void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}

    public string GetName()
    {
        return Item_Name;
    }
}
